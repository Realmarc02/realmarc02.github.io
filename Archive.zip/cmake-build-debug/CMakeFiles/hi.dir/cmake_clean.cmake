file(REMOVE_RECURSE
  "CMakeFiles/hi.dir/main.cpp.o"
  "CMakeFiles/hi.dir/main.cpp.o.d"
  "hi"
  "hi.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/hi.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
